# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['brain_games', 'brain_games.games', 'brain_games.scripts']

package_data = \
{'': ['*']}

install_requires = \
['prompt>=0.4.1,<0.5.0']

entry_points = \
{'console_scripts': ['brain-calc = brain_games.scripts.brain_calc:main',
                     'brain-even = brain_games.scripts.brain_even:main',
                     'brain-games = brain_games.scripts.brain_games:main',
                     'brain-gcd = brain_games.scripts.brain_gcd:main']}

setup_kwargs = {
    'name': 'hexlet-code',
    'version': '0.1.0',
    'description': '',
    'long_description': '### Hexlet tests and linter status:\n[![Actions Status](https://github.com/Andrey235944/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/Andrey235944/python-project-49/actions)\n\n### codeclimate status:\n[![Maintainability](https://api.codeclimate.com/v1/badges/7089e38bbb7351ae0c77/maintainability)](https://codeclimate.com/github/Andrey235944/python-project-49/maintainability)\n\n###asciinema even:\nhttps://asciinema.org/a/heR1vG047Qeh4f4Sm9UAklTnu\n\n###asciinema calc:\nhttps://asciinema.org/a/9rUqcr6qjLcXOgPExxGN68L5I\n\n###asciinema gcd:\nhttps://asciinema.org/a/5KGPzcsCW4C104lxsmK5pkg3O\n',
    'author': 'Andrey Ivlev',
    'author_email': 'ivlev-pm@mail.ru',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.10,<4.0',
}


setup(**setup_kwargs)
