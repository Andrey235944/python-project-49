### Hexlet tests:
[![Actions Status](https://github.com/Andrey235944/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/Andrey235944/python-project-49/actions)

### codeclimate status:
[![Maintainability](https://api.codeclimate.com/v1/badges/7089e38bbb7351ae0c77/maintainability)](https://codeclimate.com/github/Andrey235944/python-project-49/maintainability)

##asciinema even:
[![asciicast](https://asciinema.org/a/5oVqeDxbufJb15Dbl4WSVoGgW.png)](https://asciinema.org/a/5oVqeDxbufJb15Dbl4WSVoGgW)

###asciinema calc:
https://asciinema.org/a/9rUqcr6qjLcXOgPExxGN68L5I

###asciinema gcd:
https://asciinema.org/a/5KGPzcsCW4C104lxsmK5pkg3O
