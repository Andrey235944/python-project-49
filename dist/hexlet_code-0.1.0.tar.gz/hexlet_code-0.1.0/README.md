### Hexlet tests and linter status:
[![Actions Status](https://github.com/Andrey235944/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/Andrey235944/python-project-49/actions)

### codeclimate status:
[![Maintainability](https://api.codeclimate.com/v1/badges/7089e38bbb7351ae0c77/maintainability)](https://codeclimate.com/github/Andrey235944/python-project-49/maintainability)

###asciinema even:
https://asciinema.org/a/heR1vG047Qeh4f4Sm9UAklTnu

###asciinema calc:
https://asciinema.org/a/9rUqcr6qjLcXOgPExxGN68L5I
